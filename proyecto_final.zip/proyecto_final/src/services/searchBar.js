import { handleGetProductLocalStorage } from "../persistence/localStorage.js";
import { handleRenderList } from "../views/store.js";

export const handleSearchProductByName = () => {
    const inputHeader = document.getElementById('inputHeader');
    const searchTerm = inputHeader.value.trim().toLowerCase();  // Asegúrate de leer el valor correctamente
    
    if (!searchTerm) {
        console.log("El campo de búsqueda está vacío");
        return;
    }
    
    const products = handleGetProductLocalStorage();
    const result = products.filter((el) => 
        el.title.toLowerCase().includes(searchTerm)
    );
    
    console.log(result);  // Para verificar si el filtrado está funcionando
    handleRenderList(result);
};
