===Integrador Joaquin Redondo===

- Ejecutar desde el comando en consola de visual studio: npm run dev