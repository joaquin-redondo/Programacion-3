let a = 5
let b = 10
let c =(a + b)

console.log("la suma de a y b es :", c)

let nombre = prompt("¿Cuál es tu nombre?");
console.log(`Hola, ${nombre}!`);

let num1 = 10;
let num2 = 14;
let num3 = 7;
let mayor;

if (num1 > num2 && num1 > num3) {
  mayor = num1;
} else if (num2 > num1 && num2 > num3) {
  mayor = num2;
} else {
  mayor = num3;
}

console.log(`El mayor de los tres números es: ${mayor}`);


let numeroIngresado = prompt("Ingresa un número y te diré si es par o impar:");
numeroIngresado = parseInt(numeroIngresado);

if (numeroIngresado % 2 === 0) {
  console.log(`El número ${numeroIngresado}, es par`);
} else {
  console.log(`El número ${numeroIngresado}, es impar`);
}


let numero = 10;
console.log("Ejercicio 3");

while (numero > 0) {
  console.log(numero);  
  numero--;  
}

let numero2

do {
  numero2 = prompt("Ingresa un número mayor a 100:");
} while (numero2 <= 100);

console.log("Ingresaste un número mayor a 100:", numero2);


function esPar(numero) {
  return numero % 2 === 0;
}
console.log(`El número 8 es par: ${esPar(8)}`); 
console.log(`El número 7 es par: ${esPar(7)}`);  


function convertirCelsiusAFahrenheit(celsius) {
  return celsius * 1.8 + 32;
}


let celsius = 30;
let fahrenheit = convertirCelsiusAFahrenheit(celsius);
console.log(`${celsius}°C son equivalentes a ${fahrenheit}°F`);


let numeros = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10];
let multiplicadosPorDos = [];

for (let i = 0; i < numeros.length; i++) {
    multiplicadosPorDos.push(numeros[i] * 2);
}

console.log(`Números originales: ${numeros}`);
console.log(`Números multiplicados por 2: ${multiplicadosPorDos}`);

let pares = [];

for (let i = 1; i <= 20; i++) {
    if (i % 2 === 0) {
        pares.push(i);
    }
}

console.log(`Array de pares: ${pares}`);


